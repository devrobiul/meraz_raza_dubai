
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

         <section class="pdt-120 pb-5">
          <div class="container">
                       <div class="text-center py-5">
                    <h2> About Me</h2>
                </div>
            <div class="row align-items-center">
         
              <div class="col-md-6">
                <img src="<?php echo e(asset(setting('about_img'))); ?>" alt="<?php echo e(setting('app_name')); ?>">
              </div>
              <div class="col-md-6">
           <?php echo setting('about_description'); ?>

              </div>
            </div>
          </div>
        </section>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-lg-8" data-aos="fade-up" data-aos-duration="1000">
                <h2 class="section-title pb-0 mb-1">Education</h2>
                <p class="section-subtitle">My academic journey and learning milestones</p>
            </div>
        </div>
        <div class="row mt-5">
            <?php $__empty_1 = true; $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="<?php echo e($loop->iteration * 100); ?>">
                    <div class="edu-card p-4 shadow-sm rounded">
                        <h3><?php echo e($education->title); ?></h3>
                        <span class="text-muted"><?php echo e($education->org); ?>, <?php echo e($education->session); ?></span>
                        <?php if($education->department || $education->gpa): ?>
                            <p class="">
                                <?php if($education->department): ?>
                                    Department: <?php echo e($education->department); ?><br>
                                <?php endif; ?>
                                <?php if($education->gpa): ?>
                                    GPA: <?php echo e($education->gpa); ?>

                                <?php endif; ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center">No education records found.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

    <section id="portfolio" class="bx-portfolio-section bx-section portfolio">

        <div class="container">
                 <div class="col-md-12 col-lg-10 col-xl-6  text-center m-auto mb-5">
                        <div class="title-box-center">
                            <h6>( OUR ACHIVMENT )</h6>
                            <h2 class="title">Our Achievement & Awards</h2>
                        </div>
                    </div>
    
            <div class="portfolio-content-items">
                <div class="row" id="portfolio-mix">
                       <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php
                           $meta = json_decode($award->meta ,true);
                       ?>
                           <div class="col-lg-4 col-md-6 mix">
                                <div class="hovereffect">
                                    <a data-fancybox="gallery" href="<?php echo e(asset($award->image)); ?>">
                                        <img src="<?php echo e(asset($award->image)); ?>" alt="<?php echo e($award->title); ?>">
                                    </a>
                                    <div class="overlay">
                                        <a href="#" class="title-link"><?php echo e($award->title); ?><br> 
                                        <span><?php echo e($meta['award_org']); ?> (<?php echo e($meta['award_year'] ??''); ?>)</span>
                                        </a>
                            
                                    </div>
                                </div>
                            </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                    
                 
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.umd.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/mixitup/dist/mixitup.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var containerEl = document.querySelector('#portfolio-mix');
            if (containerEl) {
                mixitup(containerEl, {
                    selectors: {
                        target: '.mix'
                    },
                    animation: {
                        duration: 300
                    }
                });
            }

            Fancybox.bind("[data-fancybox='gallery']", {
                Toolbar: false,
                closeButton: "top",
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\MerazRazaDubai\resources\views/frontend/pages/about.blade.php ENDPATH**/ ?>