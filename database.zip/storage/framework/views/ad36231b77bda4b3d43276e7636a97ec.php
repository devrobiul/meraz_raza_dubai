

<?php $__env->startSection('content'); ?>

    <!-- Page Title End -->
    <!-- Service Section Start -->
    <section class="pdt-120 pdb-120 py-120">
        <div class="section-content">
            <div class="container">
                 <div class="text-center py-5">
    <h2>My Services </h2>
 </div>
                <div class="row">
                    <div class="col-lg-12">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="services_list_style3 wow fadeInUp" data-wow-delay="0.2s">
                                <div class="services_item">
                                    <div class="services_wrap">
                                        <div class="services_title_area">
                                            <?php
                                                $meta = json_decode($service->meta, true);
                                            ?>
                                            <div class="services_icon"
                                                style="display: inline-flex; align-items: center; justify-content: center; 
            width: 80px; height: 80px; border: 2px dashed #fff; border-radius: 50%;">
                                                <i class="<?php echo e($meta['icon']); ?> fs-1"></i>
                                            </div>

                                            <div class="services_content">
                                                <h4 class="services_title"><?php echo e($service->title); ?></h4>
                                                <p class="services_description">
                                                    <?php echo $meta['short_description']; ?>

                                                </p>
                                            </div>
                                        </div>
                                        <div class="services_thumb">
                                            <img class="parallax-img" src="<?php echo e(asset($service->image)); ?>"
                                                alt="<?php echo e($service->title); ?>" />
                                        </div>
                                        <a class="services_link" href="<?php echo e(route('single.post', ['type' => 'service', $service->slug])); ?>"><i
                                                class="webexbase-icon-up-right-arrow-1"></i></a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\MerazRazaDubai\resources\views/frontend/pages/service.blade.php ENDPATH**/ ?>