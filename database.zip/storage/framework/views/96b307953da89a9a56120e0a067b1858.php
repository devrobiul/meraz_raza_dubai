    <meta charset="UTF-8" />
    <meta name="author" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link href="<?php echo e(asset(setting('favicon'))); ?>" rel="shortcut icon" type="image/png" />
     <?php echo $__env->yieldPushContent('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/responsive.css')); ?>" /><?php /**PATH D:\Project\MerazRazaDubai\resources\views/frontend/includes/header-scripts.blade.php ENDPATH**/ ?>