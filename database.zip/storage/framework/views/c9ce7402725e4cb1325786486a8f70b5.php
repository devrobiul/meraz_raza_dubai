<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo setting('gtm_head_code'); ?>

    <?php echo SEO::generate(); ?>

<?php echo JsonLd::generate(); ?>

<?php echo setting('google_verify_meta'); ?>

    <?php echo $__env->make('frontend.includes.header-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body class="layout-dark-mood">
    <?php echo setting('gtm_body_code'); ?>

    <?php echo $__env->make('frontend.includes.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div id="smooth-wrapper">
        <div id="smooth-content">

            <?php echo $__env->yieldContent('content'); ?>

            <?php echo $__env->make('frontend.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        </div>
    </div>



        <div id="loadingPopup"
        style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 9999; text-align: center;">
        <div style="position: relative; top: 50%; transform: translateY(-50%);">
            <div class="spinner-border text-light" role="status"></div>
            <p class="text-light mt-2">Loading....</p>
        </div>
    </div>

    <div class="w-app">
        <a href="https://wa.me/<?php echo e(setting('whatsapp')); ?>" target="_blank">
     
            <img src="<?php echo e(asset('frontend/uploads/whatsapp.png')); ?>" alt="<?php echo e(setting('app_name')); ?>">
        </a>
    </div>
    <?php echo $__env->make('frontend.includes.footer-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH D:\Project\MerazRazaDubai\resources\views/frontend/layout/app.blade.php ENDPATH**/ ?>