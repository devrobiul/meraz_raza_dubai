
  
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Live PHP</title>
  <style>
    body{ font-family:sans-serif; margin-top:1rem; }
    a{ text-transform:uppercase; color:red }
    h1,p,a{ margin-left:1rem; height: 3rem;}
  </style>
</head>
<body>
  <h1>Hello dev! 👌</h1>
  <p>Edit Me please</p>
  <a href="./views/home.php" >Navigate to Home Page</a>
</body>
</html>