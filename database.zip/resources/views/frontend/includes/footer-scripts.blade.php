    <script src="{{asset('frontend/js/jquery-3.7.1.min.js')}}"></script>
    <script src="{{asset('frontend/js/jquery.nice-select.min.js')}}"></script>
    <script src="{{asset('frontend/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('frontend/js/jquery.appear.min.js')}}"></script>
    <script src="{{asset('frontend/js/wow.min.js')}}"></script>
    <script src="{{asset('frontend/js/swiper.min.js')}}"></script>
    <script src="{{asset('frontend/js/jquery.waypoints.min.js')}}"></script>
    <script src="{{asset('frontend/js/jquery.counterup.min.js')}}"></script>
    <script src="{{asset('frontend/js/jquery.event.move.js')}}"></script>
    <script src="{{asset('frontend/js/gsap-plugins.js')}}"></script>
    <script src="{{asset('frontend/js/gsap-trigger.js')}}"></script>
    <script src="{{asset('frontend/js/title-animations.js')}}"></script>
    <script src="{{asset('frontend/js/ukiyo.min.js')}}"></script>
    <script src="{{asset('frontend/js/three.js')}}"></script>
    <script src="{{asset('frontend/js/hover-effect.umd.js')}}"></script>
    <script src="{{asset('frontend/js/tilt.jquery.min.js')}}"></script>
    <script src="{{asset('frontend/js/magnific-popup.min.js')}}"></script>
    <script src="{{asset('frontend/js/backtotop.js')}}"></script>
    <script src="{{asset('frontend/js/trigger.js')}}"></script>

    @stack('js')

